# Python Projects

Hello!

This repo has been created with the goal of giving new programmers a simple way to check out code of more advanced users. This allows for faster and better learning and will also help with understanding more complex algorithms. 

All contributions of programs are welcome, but please consider the following:
1. Only submit projects that have been written in Python 3.x
2. Projects with many subfolders or many files have to go into their own subfolder
3. All projects have to be commented, so the beginners can understand it.
