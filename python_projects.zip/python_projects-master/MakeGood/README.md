Python 3
======

A small script that makes everything good.
Works pretty well, when you have a bad mood.
* Just run make_good.py 
